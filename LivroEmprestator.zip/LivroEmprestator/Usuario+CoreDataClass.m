//
//  Usuario+CoreDataClass.m
//  LivroEmprestator
//
//  Created by ALUNO on 01/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Usuario+CoreDataClass.h"

@implementation Usuario

@end
