//
//  viewForZoomingInScrollView:.h
//  autoLayout
//
//  Created by ALUNO on 11/10/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface viewForZoomingInScrollView_ : UIScrollView

@end
