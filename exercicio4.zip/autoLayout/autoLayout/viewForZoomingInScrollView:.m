//
//  viewForZoomingInScrollView:.m
//  autoLayout
//
//  Created by ALUNO on 11/10/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "viewForZoomingInScrollView:.h"

@implementation viewForZoomingInScrollView_

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
 */


@end
