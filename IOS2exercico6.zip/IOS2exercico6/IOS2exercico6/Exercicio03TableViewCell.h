//
//  Exercicio03TableViewCell.h
//  IOS2exercico6
//
//  Created by ALUNO on 01/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Exercicio03TableViewCell : UITableViewCell

@end
