//
//  Exercio01TableViewCell.m
//  IOS2exercico6
//
//  Created by ALUNO on 31/10/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Exercio01TableViewCell.h"

@implementation Exercio01TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
