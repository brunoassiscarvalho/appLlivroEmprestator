//
//  Livro+CoreDataClass.m
//  LivroEmprestator
//
//  Created by ALUNO on 01/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import "Livro+CoreDataClass.h"

@implementation Livro

@end
