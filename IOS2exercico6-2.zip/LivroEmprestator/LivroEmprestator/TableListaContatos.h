//
//  TableListaContatos.h
//  LivroEmprestator
//
//  Created by ALUNO on 31/08/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableListaContatos : UITableViewController

@end
