//
//  ViewControllerLivro.h
//  LivroEmprestator
//
//  Created by ALUNO on 01/11/16.
//  Copyright © 2016 IESB. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Livro+CoreDataClass.h"

@interface ViewControllerLivro : UIViewController
@property Livro *livroSelecionado;

@end
